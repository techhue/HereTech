
var hello = "Hello World!"
//hello = 100
print(hello)

hello = "Namaskar Mandali!"
print(hello)

let maximumNumberOfLogins = 10
var currentLoginAttempt = 0

//maximumNumberOfLogins = 100

print(currentLoginAttempt)
currentLoginAttempt = 110
print(currentLoginAttempt)

let a: Int8 = 127
let b: Int8 = 1

//let c: Int8 = a + b
//let c: Int8 = 127 + b
//let c: Int8 = 127 + 1

let aa: Int8 = 20
let bb: Int = 1000
let cc = Int(aa) + bb
print(cc)


let minValueOfInt8 = Int8.min
let maxValueOfInt8 = Int8.max
let minValueOfInt8_Unsigned = UInt8.min
let maxValueOfInt8_Unsigned = UInt8.max
print(minValueOfInt8, maxValueOfInt8)
print(minValueOfInt8_Unsigned, maxValueOfInt8_Unsigned)


let minValueOfInt16 = Int16.min
let maxValueOfInt16 = Int16.max
let minValueOfInt16_Unsigned = UInt16.min
let maxValueOfInt16_Unsigned = UInt16.max
print(minValueOfInt16, maxValueOfInt16)
print(minValueOfInt16_Unsigned, maxValueOfInt16_Unsigned)


let minValueOfInt = Int.min
let maxValueOfInt = Int.max
let minValueOfInt_Unsigned = UInt.min
let maxValueOfInt_Unsigned = UInt.max
print(minValueOfInt, maxValueOfInt)
print(minValueOfInt_Unsigned, maxValueOfInt_Unsigned)


let minValueOfInt64 = Int64.min
let maxValueOfInt64 = Int64.max
let minValueOfInt64_Unsigned = UInt64.min
let maxValueOfInt64_Unsigned = UInt64.max
print(minValueOfInt64, maxValueOfInt64)
print(minValueOfInt64_Unsigned, maxValueOfInt64_Unsigned)


//Constant Literals or Values Have Default Type in Swift
//Rules Are Highly Influnced From C Language

/*
10 //Int Value Of Int Type
10.9 //Double Value of Double Type Not Float Type
"Ding Dong" //String Value of String Type in Swift But In C There Is No String Type Exists
true //Boolean Value of Boolean Type
*/

let pi = 3.14159
print(pi)

let anotherPi = 3 + 0.14159
print(anotherPi)

var three: Int = 3 // three binded with Int
let piFraction = 0.14159 // piFraction is binded with Double
//let piValue = three + piFraction // Int + Double it's Error
let piValue = Double(three) + piFraction // Int + Double it's Error
print(piValue)

//var three: Double = 3.14159 // NOTE: It is Not Possible to Redeclare and Change Type
let decimalInteger = 17 // Int Type with Base 10
let binaryInteger = 0b10001 // Int Type with Base 2
let octalInteger = 0o21 // Int Type with Base 8
let hexaDecimalInteger = 0x11 // Int Type with Base 16

print(decimalInteger)
print(binaryInteger)
print(octalInteger)
print(hexaDecimalInteger)

// void playWithFloatingPoint() {
// 	float f1 = 2.398978111;
// 	float f2 = 2.398978112;

// 	if ( f1 == f2 ) {
// 		printf("\nFloating Points Are Equal\n");
// 	} else {
// 		printf("\nFloating Points Are UNEqual\n");
// 	}
// }

let f1: Float = 2.398978111
let f2: Float = 2.398978112
if ( f1 == f2 ) {
	print("\nFloating Points Are Equal\n")
} else {
	print("\nFloating Points Are UNEqual\n")
}

//Value is 12.1875 and Data Type is Double Always For Following Cases
//Neither Value Changes Not Data Type Because of Representation/Format
//i.e. Representation/Format of Data is NOT part of Data Type Definition
let decimalValue = 12.1875
let exponetValue = 1.21875e1
let hexaDecimalValue = 0xC.3p0

print(decimalValue)
print(exponetValue)
print(hexaDecimalValue)

/*
	A. CTE
	B. RTE 1
	C. 2001 5
	D. None Of These 1
*/
let twoThousad: UInt16 = 2_000
let one: UInt8 = 1
let twoThousadAndOne = twoThousad + UInt16(one)
//let twoThousadAndOne = UInt8(twoThousad) + one // Leads To RunTime Error Because of Type Mess
print(twoThousadAndOne)


let someValue = Int(4.75)
let anotherValue = Int(-4.75)
print(someValue)
print(anotherValue)
print(Int.min, Int.max)

let someValue1 = UInt(4.75)
//let anotherValue1 = UInt(-4.75)
print(someValue1)
//print(anotherValue1)
print(UInt.min, UInt.max)

typealias AudioSample = UInt16
var minSoundLevel = AudioSample.min
var maxSoundLevel = AudioSample.max
print(minSoundLevel, maxSoundLevel)

let stereoSound: AudioSample = 10
print(stereoSound)

let orangesAreOrgance: Bool = true
let turnipsAreDelicious: Bool = false

/* if-else expression
___________________________________________________________________________________
	Expression should Boolean Type and Boolean Value
	if (Expression) {
		//IF BODY
	} else {
		//ELSE BODY
	}
*/
if turnipsAreDelicious && turnipsAreDelicious {
	print("Delicicous Dish!")
} else {
	print("What The Hell This Is...!")
}

//Swift Implicit Conversions Is NOT Allowed
//In Swift for Following Code 
// 		Neither Type Conversion, Nor Value Conversion Happens.
var x = 10
//if (x) {	 	// NOT ALLOWED
//if Boo(x) { 	// NOT ALLOWED
if x == 10 {
	print("Balleeeee Balleeeee")
} else {
	print("Go To The Hell....")
}

// if x = 10 { // ERROR in SWIFT
// 	print("Balleeeee Balleeeee")
// } else {
// 	print("Go To The Hell....")
// }

//Tuple : Following is Tuple of (Int, String)
let http404Error: (Int, String) = (404, "Not Found")
print("The Error Code is \(http404Error.0)")
print("The Error Status is \(http404Error.1)")

//Tuple : Following is Tuple of (Int, String)
let http404Status = (code: 404, status: "Not Found")
print("The Error Code is \(http404Status.code)")
print("The Error Status is \(http404Status.status)")

//var someTuple: (Int, String) = (10, "Ding Dong")
var someTuple: (Int, Int) = (10, 20)
//someTuple = http404Error

//Tuple Unpacking!
let (xx, yy) = someTuple
print(xx)
print(yy)

print( xx + yy )
print( xx - yy )
print( xx * yy )
print( xx / yy )

print( 9 % 4 )
print( -9 % 4 )
print( 9 % -4 )
print( -9 % -4 )

print( 1 == 1 )
print( 2 != 1 )
print( 2 > 1 )
print( 2 >= 1 )
print( 3 < 10 )
print( 3 <= 10 )

let name = "World"
if name == "World" {
	print("Hello World!")
} else {
	print("Met with Alien...")
}

let contentHeight = 40
let hasSomething = false
let rowHeight = contentHeight + ( hasSomething ? 50 : 30 )
print(rowHeight)

// a...b Range Operator: It's Close Interval [a, b]
for index in 1 ... 5 {
	print( "\(index) times 5 is \(index * 5)" )
}

let names = ["Anna", "Dyna", "Ashwarya", "Katrina", "Sonali Kulkarni", "Mukta Barve"]

// a..<b Range Operator: It's Semi-Closed Interval [a, b)
for i in 0 ..< names.count {
	print(names[i])
}

let allowedEntry = false
if !allowedEntry {
	print("ACCESS DENIED!")
}

let doorCode = true
let passedRetinaScan = false
if doorCode && passedRetinaScan {
	print("Access Allowed!")
} else {
	print("ACCESS DENIED!")	
}

let myUncleIsPM = true
let everyThingPossible = true

if (doorCode && passedRetinaScan) || myUncleIsPM || everyThingPossible {
	print("Access Allowed!")
} else {
	print("ACCESS DENIED!")	
}

for name in names {
	print(name)
}

//Indexing Loop: NOT SUPPORTED In SWIFT 3.0 ONWARDS
//for (i = 0 ; i <= UpperNumber ; i++ ) {     }


