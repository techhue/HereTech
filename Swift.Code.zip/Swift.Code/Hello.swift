//Save As Hello.swift

let hello = "Hello World!"
print(hello)

let greeting = "Welcome to Swift Programming Language!"
print(greeting)
