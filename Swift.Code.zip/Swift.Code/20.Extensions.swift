//Swift Extensions

extension Double {
    var km: Double { return self * 1_000.0 }
    var m: Double  { return self }
    var cm: Double { return self / 100.0 }
    var mm: Double { return self / 1_000.0 }
    var ft: Double { return self / 3.28084 }
}

let oneInch = 25.4.mm
print("One inch is \(oneInch) meters")

let threeFeet = 3.ft
print("Three feet is \(threeFeet) meters")

let aMarathon = 42.km + 195.m
print("A marathon is \(aMarathon) meters long")

// One inch is 0.0254 meters
// Three feet is 0.914399970739201 meters
// A marathon is 42195.0 meters long

extension Int {
    func repetitions(task: () -> ()) {
        for _ in 0..<self {
            task()
        }
    }
}

3.repetitions(task: { print("Hello!") })
3.repetitions { 
	print("Goodbye!") 
}

extension Int {
    mutating func square() {
        self = self * self
    }
}

var someInt = 3
print(someInt)
someInt.square()
print(someInt)

//____________________________________________________

extension Int {
    subscript( index: Int ) -> Int {
    	var digitIndex = index
        var decimalBase = 1
        while digitIndex > 0 {
            decimalBase = decimalBase * 10
            digitIndex = digitIndex - 1
        }
        return (self / decimalBase) % 10
    }
}

//Using Subscript Operator To Get Digit at Particular Place Values
// subscript(index: )
print( 746381295[0] )
print( 746381295[1] ) 
print( 746381295[2] )
print( 746381295[8] )
print( 746381295[9] )

// 5
// 9
// 2
// 7
// 0

extension Int {
    enum Kind {
        case Negative, Zero, Positive
    }
    var kind: Kind {
        switch self {
        case 0:
            return .Zero
        case let x where x > 0:
            return .Positive
        default:
            return .Negative
            }
    }
}

print( 10.kind )
print( 0.kind )
print( (-10).kind )

func printIntegerKinds(numbers: [Int]) {
    for number in numbers {
        switch number.kind {
        case .Negative:
            print("- ", terminator: "")
        case .Zero:
            print("0 ", terminator: "")
        case .Positive:
            print("+ ", terminator: "")
        }
    }
}
printIntegerKinds(numbers: [10, 20, -10, -20, 0, 0, 100, 1000, -900])

