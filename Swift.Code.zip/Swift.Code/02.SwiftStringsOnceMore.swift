
var someString = "Hello Welcome!"
print(someString)

someString += "Ding Dong"
print(someString)

someString.append("Ming Mong")
print(someString)

//let exclamationMark = "!"
//In Swift : It's Unicode Character
let exclamationMark: Character = "!"
print(exclamationMark)

//Unicode Character
let someCharacters: [Character] = ["C", "a", "t", "!"]
print(someCharacters)

let catValue  = String(someCharacters)
print(catValue)


for item in catValue {
	print(item)
}

//String Interpolation
//Take The Values and Convert It Into String Type
//Substitute The Place Holder with String Value

let someNumber = 10
//In C/C++/Java 
//printf("Number Value Is: %s", someNumber)

//Place Holder is \(SOMETHING)
//String(SOMETHING) and Substitute Place Holder \()
print("Number Value Is: " + String(someNumber))
print("Number Value Is: \(someNumber)")

let name = "Rosa"
let welcomeString = "Welcome, " + name + "!"
print(welcomeString)

let personalizedGreeting = "Welcome, \(name)!"
print(personalizedGreeting)

let price = 2
let number = 3
let cookiePrice = "\(number) cookies: $\(price * number)."
print(cookiePrice)

let cookiePriceGenerated = String(number) + " cookies: $" + String(price * number) 
print(cookiePriceGenerated)

// cookiePrice == "3 cookies: $6."

//Unicode Point is Number Part of Unicode Standard for A Language
let someChar: Character = "\u{D55C}"
print(someChar)

let someChar1: Character = "\u{1112}"
let someChar2: Character = "\u{1161}"
let someChar3: Character = "\u{11AB}"
let someChar4: Character = "\u{1112}\u{1161}\u{11AB}"
print(someChar1)
print(someChar2)
print(someChar3)
print(someChar4)

let eAcuteQuestion = "Voulez-vous un caf\u{65}\u{301}"
print(eAcuteQuestion)
let eAcuteQuestion1 = "Voulez-vous un cafe\u{301}"
print(eAcuteQuestion1)
let eAcuteQuestion2 = "Voulez-vous un caf\u{E9}"
print(eAcuteQuestion2)

if eAcuteQuestion == eAcuteQuestion1 {
	print("Equal...")
} else {
	print("UNEqual...")
}

if eAcuteQuestion2 == eAcuteQuestion1 {
	print("Equal...")
} else {
	print("UNEqual...")
}

let dialoguesShole = [
	"Act 1 Scence 1: Kitne Aaadmeeeeeeeeen Thee",
	"Act 1 Scence 2: Sardar 3",
	"Act 1 Scence 3: Sardar Main Apka Namaak Khaya",
	"Act 2 Scence 2: Chal Chamiyaan Nach...",
	"Act 2 Scence 3: Jab Thak Thumhare Panv Chalainge... Tab Tak Eski Sasann...",
	"Act 2 Scence 4: En Kuthoon Ke Saamnee Nachanaaa"
]

var dialogueCount = 0
var dialogueContinuityCount = 0
for dialogue in dialoguesShole {
	if dialogue.hasPrefix("Act 1") {
//		print(dialogue)
		dialogueCount = dialogueCount + 1
	} 

	if dialogue.hasSuffix("...") {
		dialogueContinuityCount = dialogueContinuityCount + 1
	}
}
print(dialogueCount)
print(dialogueContinuityCount)

print("Appreciate Unicode Point and Unicode Character")
let stringValue = "Ding Dong"

for unicodePoint in stringValue.utf8 {
	print(unicodePoint)
}

for unicodePoint in stringValue.utf16 {
	print(unicodePoint)
}

for unicodePoint in stringValue.unicodeScalars {
	print(unicodePoint)
	print(unicodePoint.value)
}

print("Length of String: \(stringValue) is \(stringValue.count)")

// let banner = """
//           __,
//          (           o  /) _/_
//           `.  , , , ,  //  /
//         (___)(_(_/_(_ //_ (__
//                      /)
//                     (/
//         """
// print(banner)
let name1 = "MarieCurie"
//let firstSpace = name1.firstIndex(of: " ") 
let firstSpace = name1.firstIndex(of: " ") ?? name1.endIndex
print(firstSpace)
let firstName = name1[..<firstSpace]
print(firstName)

let stringMemebers: [Character] = Array(name1)
print(stringMemebers)

let cafe = "Cafe\u{301} du 🌍"
print(cafe)
let cafeUTF8 = cafe.utf8
let cafeUTF8_Array = Array(cafeUTF8)
print(cafeUTF8.count)
print(cafeUTF8_Array)

let cafeUTF16 = cafe.utf16
let cafeUTF16_Array = Array(cafeUTF16)
print(cafeUTF16.count)
print(cafeUTF16_Array)