
struct Fahrenheit {
	var temprature: Double = 0
	var place: String = ""

	//Compiler Generate This One Internally: Memberwise Initilizer
	// init(temprature: Double, place: String) {
	// 	self.temprature = temprature
	// 	self.place = place
	// }

	init(temprature: Double = 0, place: String = "") {
		self.temprature = temprature
		self.place = place
	}
}

var ff = Fahrenheit(temprature: 110, place: "Mumbai")
print("Fahrenheit Value: \(ff)")

var ff1 = Fahrenheit(temprature: 110)
print("Fahrenheit Value: \(ff1)")

var ff2 = Fahrenheit()
print("Fahrenheit Value: \(ff2)")


//____________________________________________________________________
// 6. Function Overloading
// 		Function With Mutliple Forms: 
// 			By Parameter Numbers and/or Type and/or Parameter Names


struct Celsius {
	var temperatureInCelsius: Double = 0.0
    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }

    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }
}

let boilingPoint = Celsius(fromFahrenheit: 212.0 )
print(boilingPoint)
let freezingPoint = Celsius(fromKelvin: 273.15 )
print(freezingPoint)

// Celsius(temperatureInCelsius: 100.0)
// Celsius(temperatureInCelsius: 0.0)

//____________________________________________________________________
// Optional will Set To Default Value: nil

struct Fahrenheit2 {
	var temprature: Double = 0
	var place: String?  // By Defalut It Get Initlized To nil
}

var ff21 = Fahrenheit2(temprature: 110, place: "Mumbai")
print("Fahrenheit Value: \(ff21)")

var ff23 = Fahrenheit2()
print("Fahrenheit Value: \(ff23)")


//____________________________________________________________________
//Various Kind of Initlizors and Default Generated One

struct Fahrenheit1 {
	// var temprature: Double
	// var place: String

	var temprature: Double = 0
	var place: String = ""

	//C++/Java/C# Will Generate Default Constructor
	//Which Doesn't Take Any Arguments
	// Fahrenheit() { }

	init() {
		temprature = 0
		place = ""
	}

	// init(temprature: Double) {
	// 	self.temprature = temprature
	// 	self.place = ""
	// }

	// //C++/Java/C# Will Generate Default Constructor: Memberwise Initiatlizer
	// //Which Takes All Properties As Arguments...
	// init(temprature: Double, place: String) {
	// 	self.temprature = temprature
	// 	self.place = place
	// }

	init(temprature: Double = 0, place: String = "") {
		self.temprature = temprature
		self.place = place
	}
}

var f1 = Fahrenheit1(temprature: 90, place: "Mumbai")
print("Fahrenheit Value: \(f1)")

var f2 = Fahrenheit1(temprature: 100)
print("Fahrenheit Value: \(f2)")

var f3 = Fahrenheit1(place: "Bombay")
print("Fahrenheit Value: \(f3)")

var f4 = Fahrenheit1()
print("Fahrenheit Value: \(f4)")

//____________________________________________________________________
// Initlizers in Inheritance

class Vehicle {
    var numberOfWheels = 0
    var description: String {
        return "\(numberOfWheels) wheel(s)"
    }

    func start() {
    	print("Start The Vehicle")
    }
}

let vehicle = Vehicle()
// print(vehicle)
print("Vehicle: \(vehicle.description)")
vehicle.start()

class Bicycle: Vehicle {
    override init() {
        super.init()
        print(numberOfWheels)
        numberOfWheels = 2
        print(numberOfWheels)
    }

    override func start() {
    	print("Start The Bicycle")
    }
}

let bicycle = Bicycle()
// print(bicycle)
print("Bicycle: \(bicycle.description)")
bicycle.start()

// Vehicle: 0 wheel(s)
// Bicycle: 2 wheel(s)

//____________________________________________________________________
// Initlizers in Inheritance
// Designated Intilizers

print("\nDesignated/Convenience Intilizers....")

class Vehicle1 {
    var numberOfWheels: Int
    var description: String {
        return "\(numberOfWheels) wheel(s)"
    }

    convenience init() {
    	self.init(numberOfWheels: 0)
    }

    //Designed Initizer: ALL Memberwise Initlizer
    init(numberOfWheels: Int = 0) {
    	self.numberOfWheels = numberOfWheels
    }
}

let vehicle1 = Vehicle1()
print("Vehicle1: \(vehicle1.description)")

class Bicycle1: Vehicle1 {
    override init(numberOfWheels: Int = 2) {
    	//super.init()
        super.init(numberOfWheels: numberOfWheels)
        self.numberOfWheels = numberOfWheels
    }
}

let bicycle1 = Bicycle1()
print("Bicycle1: \(bicycle1.description)")

//____________________________________________________________________

class Food {
    var name: String
    init(name: String) {
        self.name = name
    }
    convenience init() {
        self.init(name: "[Unnamed]")
    }
}
let namedMeat = Food(name: "Bacon")
let mysteryMeat = Food()

class RecipeIngredient: Food {
    var quantity: Int
    init(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
    }
    override convenience init(name: String) {
        self.init(name: name, quantity: 1)
    }
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)


//____________________________________________________________________

class Animal {
    let species: String
    init?(species: String) {
        if species.isEmpty { return nil }
        self.species = species
    }

    deinit {
    	print("Deinitlizing...\(species)")
    }
}

var someCreature = Animal(species: "Giraffe")
print(someCreature!.species)
someCreature = nil


// if let someCreature = Animal(species: "Giraffe") {
// 	print(someCreature)
// }

// let someCreatureTemp: Animal? = Animal(species: "Giraffe")
// if someCreatureTemp != nil {
// 	let someCreature = someCreatureTemp!
// 	print(someCreature)
// 	someCreatureTemp = nil
// }


// if let someCreature1 = Animal(species: "") {
// 	print(someCreature1)
// } else {
// 	print("Nothiness Found...")
// }


