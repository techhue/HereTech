
var names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

//Sorting Criterias
func backward(s1: String, s2: String) -> Bool { return s1 > s2 }
func forward(s1: String, s2: String) -> Bool  { return s1 < s2 }
func backward_length(s1: String, s2: String) -> Bool { return s1.count > s2.count }
func forward_length(s1: String, s2: String) -> Bool { return s1.count < s2.count }

//Sorting Logic
print(names)
var result = names.sorted( by: backward )
print(result)

result = names.sorted( by: forward )
print(result)

result = names.sorted( by: forward_length )
print(result)

result = names.sorted( by: backward_length )
print(result)

func sum(x: Int, y: Int) -> Int {
	return x + y
}

var mathFunction: (Int, Int) -> Int = sum
print(mathFunction(10, 20))

//Anonymous Functions.                  Closure/Lambda
var mathFunction1: (Int, Int) -> Int =  { (x: Int, y: Int) -> Int in return x + y }
print(mathFunction1(10, 20))

result = names.sorted( by: { (s1: String, s2: String) -> Bool in return s1 > s2 } )
print(result)

result = names.sorted( by: { (s1, s2) -> Bool in return s1 > s2 } )
print(result)

result = names.sorted( by: { (s1, s2) in return s1 > s2 } )
print(result)

result = names.sorted( by: { $0 > $1 } )
print(result)

result = names.sorted( by: > )
print(result)

result = names.sorted( by: < )
print(result)

result = names.sorted()
print(result)
