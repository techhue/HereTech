
protocol Superpower {
	func fly() 
	func saveWorld()
}

class Spiderman: Superpower {
	func fly() {
		print("Fly Like Spiderman!")
	}

	func saveWorld() {
		print("Save World Like Spiderman!")
	}

	func dance() {
		print("Dance Like Spiderman")
	}
}

class Superman: Superpower {
	func fly() {
		print("Fly Like Superman!")
	}

	func saveWorld() {
		print("Save World Like Superman!")
	}		
}

class GoodSuperman: Superpower {
	func fly() {
		print("Fly Like Superman!")
	}

	func saveWorld() {
		print("Save World Like Superman!")
	}		
}

class Heman: Superpower {
	func fly() {
		print("Fly Like Heman!")
	}

	func saveWorld() {
		print("Save World Like Heman!")
	}			
}

class HanumanJi: Superpower {
	func fly() {
		print("Fly Like HanumanJi!")
	}

	func saveWorld() {
		print("Save World Like HanumanJi!")
	}			
}


//Type Invariant
//Type Polymorphism
//Delegations Design Patterns: Compositions
class Human { //: Spiderman {
	var power: Superpower?
	func fly() {
		//super.fly()
		power!.fly()
	}

	func saveWorld() {
		//super.saveWorld()
		power!.saveWorld()
	}
}

// Hazarooon Khavasain Aise...
// Har Khavais Pe Dam Nikleee....
// Mere Armaaan Bhaut Nikle...
// Fir Bhi Kaam Nikle....

var h = Human()
h.power = Spiderman()
h.fly()
h.saveWorld()

//h.power = Superman()
h.power = GoodSuperman()
h.fly()
h.saveWorld()

h.power = Heman()
h.fly()
h.saveWorld()

h.power = HanumanJi()
h.fly()
h.saveWorld()

