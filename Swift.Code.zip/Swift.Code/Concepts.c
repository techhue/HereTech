#include <stdio.h>
//let a: Int8 = 255

#define MAXIMUM 1000

void playWithIntTypeAndTypeCasting() {
	char a = 127;
	int three = 3;
	double piFraction = 0.14159;

	//In C Can Add Double with Int Type
	double piValue = three + piFraction;

	//char * three = "Ding Dong";
	printf("Value is %d:", a);
	printf("Value is %f:", piValue);
}


// In playWithFloatingPoint() Function What Will Happen?
// 	A. if part exectute
// 	B. else part will execute
// 	C. Output This Program is Indeterminate
//	D. None of These
void playWithFloatingPoint() {
	float f1 = 2.398978111;
	float f2 = 2.398978112;

	if ( f1 == f2 ) {
		printf("\nFloating Points Are Equal\n");
	} else {
		printf("\nFloating Points Are UNEqual\n");
	}
}

void playWithTypeCastingToInt() {
// let someValue = UInt(4.75)
// let anotherValue = UInt(-4.75)
// print(someValue)
// print(anotherValue)

	unsigned int someValue = (unsigned int) 4.75;
	unsigned int anotherValue = (unsigned int) -4.75;
	printf("\nValue is : %u", someValue);
	printf("\nValue is : %u", anotherValue);
}

// In playWithFloatingPoint() Function What Will Happen?
// 	A. if part exectute - 3
// 	B. else part will execute 
// 	C. Output This Program is Cann't Be Predicted 
//	D. CTE - 4
//	E. RTE - 1
//	F. None of These  

/* if-else expression
___________________________________________________________________________________
	Expression should result in int value where 
		nonzero int value is treated as TRUE
		and zero int value is treated FALSE

	if (Expression) {
	
	} else {
	
	}
*/

//Check This Works or NOT In Java/C#
//This IS VALID Code in C/C++
void playWithIfElse() {
	int x = -10;
	int y = 100;
	if ( x ) {
		printf("\nBalleeee Balleeee");
	} else {
		printf("\nGo The HELL....");
	}
}

// void playWithIfElse1() {
// 	int x = 0;
// 	if ( x = 100 ) { // PROGAMMER KI NIYAAT MAIN KHARABBI!
// 		printf("\nBalleeee Balleeee");
// 	} else {
// 		printf("\nGo The HELL....");
// 	}
// }

// void playWithStringEquality() {
// 	char name[] = "World";
// 	if (name == "World") {
// 		printf("Hello World!");
// 	} else {
// 		printf("Met with Alien...");
// 	}
// }

//Type Mess
int sum(int a, int b) {
	return a + b;
}


void authenticate(char Login[]) {
	int a, b;
	int numbers[1000] = {};
	scanf("Input Values: %d %d", &a, &b);
	int k = sum(a, b);

	for (int i = k ; i <= MAXIMUM ;  i++ ) {
		// ____ Compare User Name and Password...

		//Mess Negative Subscript
		printf("%c", numbers[i]);
		
		// ____ Login With User Name and Password...
	}
}

void playWithArray() {
	int i = 0;
	int number[5] = { 10, 20, 30, 40, 50 };
	for ( i = -5 ; i < 5; i++ ) {
		printf("\n%d", number[i]);
	}
}

int main() {
	//playWithFloatingPoint();
	// playWithTypeCastingToInt();
	// playWithIfElse();
	// playWithIfElse1();
	// playWithStringEquality();
	playWithArray();
}


