Code Bunk Link
_____________________________________________________________________
https://codebunk.com/b/8401100032383/
https://codebunk.com/b/840 11000 32 38 3/


Working With Swift Language
_____________________________________________________________________
	Write Swift Code Using Your Favorite Editor [ e.g. Sublime Text]
	Save It As FILENAME.swift File

Compiling Swift Code
_____________________________________________________________________
	swiftc FILENAME.swift -o OUTPUTFILENAME

	Running Compiled Code
		./OUTPUTFILENAME

Write Sum Function in C Language
_____________________________________________________________________

	int a = 32000;
	int b = 32000;

	int a = 38394398493849;
	int b = 1;
		
	int sum(int a, int b) {
	 	return a + b;
	}

	A. CTE
	B. RTE 
	C. 38394398493850
	D. NoT

Data Type Definition
_____________________________________________________________________
	Definition = { Opeartions, Range }
		Set of Operation Set and Range Set


Ideas Realted To Data Type
_____________________________________________________________________
	Data Type is Fundamental To System
		Type Inferencing - Compile/RunTime
		Type Binding	 - Compile/RunTime
		Type Stickness
		Type Specfication Explicitly/Implicitly
		Type Casting: In Swift Mostly Type Casting is Explicit 

	Data Type Has To Specified
		Explicitly : C/C++/Java/C#

		Implicitly : Python/JavaScript
			Type Inferencing
			Type Binding

		NOTE:

		In Python 
			Type Inferencing and Binding Both Happens At RunTime/Dynamic In Nature
		In Swift 
			Type Inferencing and Binding Both Happens At Compile Time
			Type Errors Are Generally Detected At Compile Time
			Strictly Typed Lanaguage

READING ASSIGNMENTS
_____________________________________________________________________
	Read Data Type Chapter [i.e. Chapter 2]
		Chapter 2 - Types, Operators and Expressions..
		Programming In C, By Kerngiham and Denish Ritchie


DESIGN GUIDELINES
_____________________________________________________________________
	Design Towards Non-Nothingness Rather Than Nothingness
	Design Towards NonNullability Rather Than Nullability
	Design Towards Immutability Rather Than Mutable

_____________________________________________________________________
What is An Object Oriented Programming???
	Deals With Objects...	
	Object is an Instance of Class
		Instance??? 
		Class???
	Object is Memory Allocated
	Object is Way of Represention in Memory


	Four Concepts
	_____________________________________________________________________
		Abstraction 	: Hiding Information, Hiding - Filtering... Showing Some Part...
						  Visibility e.g. Private/Public
		Encapsulation	: Data Hiding - Using Class as Idea
		Inheritance		: Child-Parent Relationship in Classes
		Polymporphism	: Multiple Forms
			 Using Class as Idea

Design Thinking - Broader and Deeper Thinking
_____________________________________________________________________

	Lets Visit Four Concepts Again
	_____________________________________________________________________
	Polymporphism	: Multiple Forms When Something is Invariant
		Invariant means which deoesn't Varies With Time.

		Mechanisms To Achieve Polymporphism
		_____________________________________________________________________
		1. Default Arguments Mechanisms
				Function With Mutliple Forms: Multiple Ways To Call.
				Invariant Feature: 
					Function Name, Function Signature, Function Body
				Function Call Takes Mutliple Forms

		2. Varidiac Arugments: Variable Number of Arugments
				Invariant Feature: 
					Function Name, Function Signature, Function Body		
				Function Call Takes Mutliple Forms With Arguments of Same Type

		3. Passing Function To Function : Higher Order Functions
				Function With Mutliple Forms: By Passing Different Functions
				Invariant Feature: 
					Function Name, Function Signature, Function Body
				Function Call Takes Mutliple Forms
					By Passing Different Functions

		4. Returning Function From Function : Higher Order Functions
				Function With Mutliple Forms: By Returning Different Functions
				Invariant Feature: 
					Function Name, Function Signature, Function Body
				Function Call Takes Mutliple Forms
					By Returning Different Functions

		5. Algorithm Invariance
				e.g. Sorting Functions

		6. Type Polymporphism: Type Invariance

		7. Function Overloading
				Function With Mutliple Forms: 
					By Parameter Numbers and/or Type and/or Parameter Names
				Invariant Feature: Function Name

				Function Call Takes Mutliple Forms
					By Varing Parameter Numbers and/or Type and/or Parameter Names








