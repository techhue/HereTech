#include <stdio.h>
//let a: Int8 = 255

//BAD CODE - BAD PATTERN - BAD PRACTICES
int sum((int a, int b) {
	return a + b;
}


void playWithIntTypeAndTypeCasting() {
	char a = 127;
	int three = 3;
	double piFraction = 0.14159;

	//In C Can Add Double with Int Type
	double piValue = three + piFraction;

	char * three = "Ding Dong";
	printf("Value is %d:", a);
	printf("Value is %f:", piValue);
}

void playWithFloatingPoint() {
	float f1 = 2.39897898990;
	float f2 = 2.398978;

	if ( f1 == f2 ) {
		print("Floating Points Are Equal");
	} else {
		print("Floating Points Are UNEqual");
	}
}

int main() {
	playWithFloatingPoint();
}


