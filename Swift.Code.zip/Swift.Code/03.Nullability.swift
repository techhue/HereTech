
// IN JAVA/C++/C#
// Human ram = null;
// Human ram = new Human("Ram");
// ram.dance();

// if (ram != null) {
// 	ram.dance()
// } else  {
// 	printf("Ram is Nothing...")
// }

//Swift Nothingness.... 
var nonNullable: Int = 0
//var nonNullable = 0
//var nonNullable: Int
//variable = 0
nonNullable = 100
// nonNullable = nil // You can assign nil to Int Type
nonNullable = nonNullable + 111
print(nonNullable)

var nullable: Int? = 10
print(nullable)
print(nullable!) //Unwrapping Optional To Get Value Inside Optional

nullable = nil
print(nullable)
if nullable != nil {
	print(nullable!)
} else {
	print("Found Nothingness...")
}



var nonNullableString: String = "Ding Dong"
print(nonNullableString)
//nonNullableString = nil

var nullableString: String? = "Hello World!"
print(nullableString) //Optional("Hello World!")
print(nullableString!) //Get The Value Stored Inside Optional Bucket

nullableString = nil
if nullableString != nil {
	print(nullableString!) //nil
} else {
	print("Found Nothingness...")	
}

var possibleNumber = "123ABC"
let convertedNumber: Int? = Int(possibleNumber)
if convertedNumber != nil {
	print(convertedNumber!)
} else {
	print("Found Nothingness...")		
}

//Idiomatic Style Programming
possibleNumber = "123"

//Following Code if Expression Works In These Steps
// 1. Type Cast Int(possibleNumber) and Return Value of Int?
// 2. Will generate One tempNumber and It's Type Will be Int?
// 3. Assign Value Returned by Int() to tempNumber
// 4. If will check tempNumber != nil
// 5. If It's True Then Unwrap tempNumber! and assign this value of actualNumber
// 6. and actualNumber type is Int
if let actualNumber = Int(possibleNumber) {
	print("Idiomatic Style: \(actualNumber)")
} else {
	print("Found Nothingness...")
}

// Following Code is Equivalent To Idiomatic Style
// Compiler Will Generate Internally
let tempNumberGenerated = Int(possibleNumber)
if tempNumberGenerated != nil {
	let actualNumber = tempNumberGenerated!
	print("Generated Code: \(actualNumber)")
} else {
	print("Found Nothingness...")	
}

//Idiomatic Style Programming
if let firstNumber = Int("40"), let secondNumber = Int("90"), firstNumber < secondNumber {
	let total = firstNumber + secondNumber
	print("Total Value Is: \(total)")
} else {
	print("Found Nothingness...")		
}

//Compiler Will Generate Following Code
let firstNumberGenerated  = Int("40")
let secondNumberGenerated = Int("90") 
if firstNumberGenerated != nil && secondNumberGenerated != nil {
	let firstNumberActual  = firstNumberGenerated!
	let secondNumberAcutal = secondNumberGenerated!
	if firstNumberActual < secondNumberAcutal {
		let total = firstNumberActual + secondNumberAcutal
		print("Total Value Is: \(total)")
	}
} else {
	print("Found Nothingness...")	
}

//Flat is Better Than Nested 
//Reduces Cyclomatic Complexity
//Reduces Nestedness of The Code, Hence Improves Readability
if let firstNumber = Int("40"), let secondNumber = Int("90"), let thirdNumber = Int("123ABC"),
	firstNumber < secondNumber + thirdNumber {
	let total = firstNumber + secondNumber
	print("Total Value Is: \(total)")
} else {
	print("Found Nothingness...")		
}

/*
A. CTE 
B. RTE 
C. if part Executes
D. else part Executes 5
E. None of These
*/

let a: Int? = 4
let b: Int? = nil
let c: Int? = 100
if let aa = a, let bb = b, let cc = c {
	print("Ballee Balleee")
} else {
	print("Ye Kya Hai....")
}

//Compiler Will Generate Following Code For The Just Above Code
let aTemp = a
let bTemp = b
let cTemp = c
if aTemp != nil && bTemp != nil && cTemp != nil {
	let aa = aTemp!
	let bb = bTemp!
	let cc = cTemp!
	print("Ballee Balleee")
} else {
	print("Ye Kya Hai....")
}

