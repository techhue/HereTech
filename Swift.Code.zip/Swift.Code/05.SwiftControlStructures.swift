

for index in 1 ... 5 {
    print("\(index) times 5 is \(index * 5)")
}

let names = ["Ding",  "Dong", "King", "Kong"]

var nameCount = 0
for _ in names {
	nameCount = nameCount + 1
}
print(nameCount)


let finalSquare = 25
var board = [Int](repeating: 0, count: finalSquare + 1)
board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08

var square = 0
var diceRoll = 0
while square < finalSquare {
    // roll the dice
    diceRoll = diceRoll + 1
    if diceRoll == 7 { diceRoll = 1 }
    // move by the rolled amount
    square += diceRoll
    if square < board.count {
        // if we're still on the board, move up or down for a snake or a ladder
        square += board[square]
    }
}
print("Game over!")


square = 0
diceRoll = 0
repeat {
    // move up or down for a snake or ladder
    square += board[square]
    // roll the dice
    diceRoll = diceRoll + 1 
    if diceRoll == 7 { diceRoll = 1 }
    // move by the rolled amount
    square += diceRoll
} while square < finalSquare
print("Game over!")


var temperatureInFarenheit = 30
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
}


temperatureInFarenheit = 40
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else {
    print("It's not that cold. wear a t-shirt.")
}

temperatureInFarenheit = 90
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else if temperatureInFarenheit >= 86 {
    print("It's really warm. Don't forget to wear sunscreen.")
} else {
    print("It's not that cold. wear a t-shirt.")
}

temperatureInFarenheit = 72
if temperatureInFarenheit <= 32 {
    print("It's very cold. Consider wearing a scarf")
} else if temperatureInFarenheit >= 86 {
    print("It's really warm. Don't forget to wear sunscreen.")
}

//In Java Switch Control
/* SYNTAX
//Expression should result into value of Int or String Type Only
switch(Expression) {
	case OPTION1:
		///
		break;
	case OPTION2:
		///
		break;
		.
		.
		.

	default:
}
*/


let someCharacter: Character = "e"
switch (someCharacter) {
    case "a", "e", "i", "o", "u":
        print("\(someCharacter) is a vowel")
    case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
        print("\(someCharacter) is a consonant")
    default:
        print("\(someCharacter) is not a vowel or consonant")
}

let approximateCount = 62
let countedThings = "moons orbiting Saturn"
var naturalCount: String

switch approximateCount {
	case 0:
	    naturalCount = "no"
	case 1..<5:
	    naturalCount = "a few"
	case 5..<12:
	    naturalCount = "several"
	case 12..<100:
	    naturalCount = "dozens of"
	case 100..<1000:
	    naturalCount = "hundreds of"
	default:
	    naturalCount = "manu"
}
print("There are \(naturalCount) \(countedThings).")





let somePoint = (1,1)
switch somePoint {
	case (0, 0):
	    print("(0,0) is at the origin")
	case (_, 0):
	    print("\(somePoint.0),0) is on the x-axis")
	case (0, _):
	    print("(0, \(somePoint.1)) is on the y-axis")
	case (-2...2, -2...2):
	    print("(\(somePoint)) is inside the box")
	default:
	    print("(\(somePoint)) is outside of the box")
}

let anotherPoint = (2, 0)
switch anotherPoint {
	case (let x, 0):
	    print("on the x-axis with an x value of \(x)")
	case (0, let y):
	    print("on the y-axis with a y value of \(y)")
	case let (x, y):
	    print("somewhare else at (\(x), \(y))")
}

let yetAnotherPoint = (1, -1)
switch yetAnotherPoint {
	case let (x, y) where x == y:
	    print("(\(x), \(y)) is on the line x == y")
	case let (x, y) where x == -y:
	    print("(\(x), \(y)) is on the line x == -y")
	case let (x, y):
	    print("(\(x), \(y)) is just some arbitrary point")
}

let integerToDescribe = 5
var description = "The number \(integerToDescribe) is"
switch integerToDescribe {
	case 2, 3, 5, 7, 11, 13, 17, 19:
	    description += " a prime number, and also"
	    fallthrough
	default:
	    description += " an integer."
}
print(description)



board = [Int](count: finalSquare + 1, repeatedValue: 0)
board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
square = 0
diceRoll = 0

gameLoop: while square != finalSquare {
    if ++diceRoll == 7 { diceRoll = 1}
    switch square + diceRoll {
	    case finalSquare:
	        break gameLoop
	    case let newSquare where newSquare > finalSquare:
	        continue gameLoop
	    default:
	        square += diceRoll
	        square += board[square]
	    }
}
print("Game over!")

