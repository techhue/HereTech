
class MediaItem {
	var name: String
	init( name: String) {
		self.name = name
	}
}

class Movie: MediaItem {
	var director: String
	init(name: String, director: String) {
		self.director = director
		super.init(name: name)
	}
}

class Song: MediaItem {
	var singer: String
	init(name: String, singer: String) {
		self.singer = singer
		super.init(name: name)
	}
}

let library = [
	Movie(name: "Shole", director: "Ramesh Sippy"),
	Movie(name: "Dil Chahta Hai", director: "Farhan Akhtar"),
	Song(name: "Tu He Rai...", singer: "S P Balasubramanium"),
	Song(name: "Rang Barse...", singer: "Ambitab Bachan"),
	Movie(name: "Gajani", director: "Pata Nahin"),
	Movie(name: "3 Idiots", director: "Raj Kumar Hirani"),
]


var movieCount = 0
var songCount = 0
for item in library {
	if item is Movie {
		movieCount = movieCount + 1
	} else if item is Song {
		songCount = songCount + 1
	}
}
print("Movie Count: \(movieCount)")
print("Song Count: \(songCount)")

for item in library {
	if let movie = item as? Movie {
		print("\(movie.name) Director: \(movie.director)")
	} else if let song = item as? Song {
		print("\(song.name) Singer: \(song.singer)")
	}
}

//Kar Khudi Ko Buland Itna!
//Ki Khudha Bhi Puche Ki...
//Tere Raaajaaaa Kya Hai...
var something: MediaItem = Movie(name: "ZNMD", director: "Zoya Akhtar")
print(something, something.name)

var some = something as! Movie
print(some, some.name, some.director)


struct BlackjackCard {    
    // nested Suit enumeration
    enum Suit: Character {
        case Spades = "♠", Hearts = "♡", Diamonds = "♢", Clubs = "♣"
    }
    
    // nestedRank enumeration
    enum Rank: Int {
        case Two = 2, Three, Four, Five, Six, Seven, Eight, Nine, Ten
        case Jack, Queen, King, Ace
        struct Values {
            let first: Int, second: Int?
        }
        var values: Values {
            switch self {
            case .Ace:
                return Values(first: 1, second: 11)
            case .Jack, .Queen, .King:
                return Values(first: 10, second: nil)
            default:
                return Values(first: self.rawValue, second: nil)
            }
        }
    }
    
    // BlackjackCard properties and methods
    let rank: Rank, suit: Suit
    var description: String {
        var output = "suit is \(suit.rawValue),"
        output += " value is \(rank.values.first)"
        if let second = rank.values.second {
            output += " or \(second)"
        }
        return output
    }
}

let theAceOfSpades = BlackjackCard(rank: .Ace, suit: .Spades)
print("theAceOfSpades: \(theAceOfSpades.description)")





