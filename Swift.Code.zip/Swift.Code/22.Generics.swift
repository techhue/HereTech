
struct IntStack {
    var items = [Int]()
    mutating func push(item: Int) {
        items.append(item)
    }
    mutating func pop() -> Int {
        return items.removeLast()
    }
}

var IntItems = IntStack()
IntItems.push( item: 10)
IntItems.push( item: 20)
IntItems.push( item: 33)
IntItems.push( item: 40)

print( IntItems.pop() )
print( IntItems.pop() )
print( IntItems.pop() )

struct StringStack {
    var items = [String]()
    mutating func push(item: String) {
        items.append(item)
    }
    mutating func pop() -> String {
        return items.removeLast()
    }
}

var strItems = StringStack()
strItems.push( item: "Ding")
strItems.push( item: "Dong")
strItems.push( item: "Ting")
strItems.push( item: "Tong")

print( strItems.pop() )
print( strItems.pop() )
print( strItems.pop() )

//Generics - Type Invariant
struct Stack<T> {
	var items = [T]()
    mutating func push(item: T) {
        items.append(item)
    }
    mutating func pop() -> T {
        return items.removeLast()
    }
}

var strItems1 = Stack<String>()
strItems.push( item: "DingGG")
strItems.push( item: "DongGG")
strItems.push( item: "TingGG")
strItems.push( item: "TongGG")

print( strItems.pop() )
print( strItems.pop() )
print( strItems.pop() )

var intItems = Stack<Int>()
intItems.push( item: 100)
intItems.push( item: 200)
intItems.push( item: 333)
intItems.push( item: 400)

print( intItems.pop() )
print( intItems.pop() )
print( intItems.pop() )
