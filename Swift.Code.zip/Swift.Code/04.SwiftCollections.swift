//Swift Collections 
//__________________________________________________________________

var someInts1: [Int] = []
//var someInts1 = []
print(someInts1)

var someInts = [Int]()
//var someInts: [Int] = [Int]() 
print(someInts)
print(someInts.count)

var threeDouble = [Double](repeating: 3.0, count: 3) 
print(threeDouble)

var anotherThreeDoubles = [Double](repeating: 2.5, count: 3) 
print(anotherThreeDoubles)

threeDouble = threeDouble + anotherThreeDoubles
print(threeDouble)

var shoppingList0: [String] = []
if shoppingList0.isEmpty {
	print("Tera Life Main Koi Interest Nahin...")
} else {
	print("Let's Go For Shopping....")
}
print(shoppingList0.count)

var shoppingList: [String] = ["Eggs", "Milk"]
print(shoppingList)
print(shoppingList.count)

shoppingList = shoppingList + ["Floor", "Pizza", "Hyderabadi Biryani"]
print(shoppingList)
print(shoppingList.count)

if shoppingList.isEmpty {
	print("Tera Life Main Koi Interest Nahin...")
} else {
	print("Let's Go For Shopping....")
}

shoppingList.append("Chole Bhature")
print(shoppingList)
print(shoppingList.count)

shoppingList += ["Ding", "Dong", "Ming", "Mong"]
print(shoppingList)

var firstItem = shoppingList[0]
shoppingList[0] = "Paneer"
print(shoppingList)

shoppingList[4...6] = ["Banannas", "Apples"]
print(shoppingList)
shoppingList[4...6] = []
print(shoppingList)

shoppingList.insert("Rasgula", at: 0) //OLDER API: .insert("Rasgula", atIndex: 0)
print(shoppingList)
let removedItem = shoppingList.remove(at: 0)
print(shoppingList)
print(removedItem)

let lastItem = shoppingList.removeLast()
print(lastItem)
print(shoppingList)

let firstItem1 = shoppingList.removeFirst()
print(firstItem1)

//Default Loop is for-in loop
//Type of item is String
for item in shoppingList {
	print(item)
}

print("Sorted Shopping List....")
for item in shoppingList.sorted() {
	print(item)
}

//Reommended Practice: Use Always for-in loop.
//To Use Indexes: Specially Generate It!
//Type of item is Tuple(Int, String)
for item in shoppingList.enumerated() {
	print(item)
}

for (index, value) in shoppingList.enumerated() {
	if index % 2 == 0 {
		print("At \(index) Value Is: \(value)")
	}
}

//Mathematical Set
//	Order Doesn't Matter
//	Duplicates Doesn' Matter
var letters: Set<Character> = Set<Character>()
//var letters = Set<Character>()
print(letters)
print(letters.count)

if letters.isEmpty {
	print("Emptiness Found...")
} else {
	print("Something is There For Sure...")
}

let favoriteGenres0 : [String] = [ "Folk", "Rock", "Metal", "Classical", "Folk" ]
//let favoriteGenres0 = [ "Folk", "Rock", "Metal", "Classical", "Folk" ]
var favoriteGenres1 : Set<String> = [ "Folk", "Rock", "Metal", "Classical", "Folk" ]
print(favoriteGenres0)
print(favoriteGenres0.count)
print(favoriteGenres1)
print(favoriteGenres1.count)

if favoriteGenres1.isEmpty {
	print("Emptiness Found...")
} else {
	print("Something is There For Sure...")
}

favoriteGenres1.insert("Hip Hop")
favoriteGenres1.insert("Pop")
favoriteGenres1.insert("Classical")
print(favoriteGenres1)
print(favoriteGenres1.count)

if favoriteGenres1.contains("Classical") {
	print("Classical Genre Exists")
} else {
	print("Milaa Nahin Bhai...")
}

//let removeGenere: String? = favoriteGenres1.remove("Classical")
//print(removeGenere)

//USE IDIOMS: if let
if let removedItem = favoriteGenres1.remove("Classical") {
	print(removedItem)
} else {
	print("Item Not Found...")
}

//WRITE COMPILER GENERATED CODE EQUIVALENT TO ABOVE PROGRAMMER CODE
//_________________________________________________________________
let removedItemTemp = favoriteGenres1.remove("Classical")
if removedItemTemp != nil {
	let removedItem = removedItemTemp!
	print(removedItem)
} else {
	print("Item Not Found...")	
}

print("Set Items...")
for genre in favoriteGenres1 {
	print(genre)
}

print("Sorted Set Items...")
for genre in favoriteGenres1.sorted() {
	print(genre)
}

let oddDigits: Set  = [1, 3, 5, 7, 9]
let evenDigits: Set = [2, 4, 6, 8, 10]
let primeNumbers: Set = [2, 3, 5, 7]

let unionDigits 	= oddDigits.union(evenDigits)
print(unionDigits)

let intersectDigits = oddDigits.intersection(primeNumbers)
print(intersectDigits)

let unionDigits1 	= oddDigits.union(primeNumbers)
print(unionDigits1)

//Dictionaries
// Collection of Key, Value Pairs

var airports = [String: String]()
if airports.isEmpty {
	print("Emptiness Found...")
} else {
	print("There are Airports...")
}

airports = ["TOR": "Toronto", "BLR": "Bangalore", "MUM": "Mumbai"]
//var airports = ["TOR": "Toronto", "BLR": "Bangalore", "MUM": "Mumbai"]
print(airports)

if airports.isEmpty {
	print("Emptiness Found...")
} else {
	print("There are Airports...")
}
// print(airports["MUM"])
// print(airports["DEL"])
if let airport = airports["MUM"] {
	print(airport)
} else {
	print("Unknown Airport...")
}

airports["DEL"] = "Delhi"
print(airports)
airports["TOR"] = "Toronto Cananda"
print(airports)

let something = airports.updateValue("Delhi Aiport", forKey: "DEL")
//print(something)
print(airports)

if let delhi = airports.updateValue("Delhi Aiport", forKey: "DEL") {
	print("\(delhi) Got Updates...")
}

//let toronto = airports.removeValue(forKey: "TOR")
// print(toronto)
if let airport = airports.removeValue(forKey: "TOR") {
	print("\(airport) Airport is Removed")
} else {
	print("Airport Doesn't Exists...")
}

for airport in airports {
	print(airport)
}

for (key, value) in airports {
	print("For \(key) Value Is: \(value)")
}

for key in airports.keys {
	print(key)
	if let airport = airports[key] {
		print(airport)
	}
}

for value in airports.values {
	print(value)
}

let airportCodes = [String](airports.keys)
//let airportCodes: [String] = [String](airports.keys)
print(airportCodes)
let airportNames = [String](airports.values)
//let airportNames: [String] = [String](airports.values)
print(airportNames)

