#include <stdio.h>

int [] minMax(int numbers[]) {
	int minMaxValues[2] = { numbers[0], numbers[0] };
	
	for (int i = 1; i < 9 ; i++ ) {
		if (number[i] < minValue) {
			minValue = number[i];
		}

		if (number[i] > maxValue) {
			maxValue = number[i];
		}
	}
	return minMaxValues;
}

int main() {
	int values[2] = minMax([10, 20, 90, -10, -100, 788, 899, 60, 70])
	printf(values[0], values[1])
}