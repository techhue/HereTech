struct Resolution {
    var width = 0
    var height = 0
}

class VideoMode {
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}

//VideoMode someVideoMode = new VideoMode(  )
//let someVideoMode: VideoMode  = VideoMode()
let someVideoMode  = VideoMode()
print(someVideoMode)
print("\(someVideoMode.resolution), \(someVideoMode.interlaced), \(someVideoMode.frameRate)")
//print("\(someVideoMode.name)")
someVideoMode.frameRate = 60.0
print("\(someVideoMode.resolution), \(someVideoMode.interlaced), \(someVideoMode.frameRate)")

//Value Type Explaination
//_________________________________________________________________
//Write Equlivatent Code In Java

// let someResolution = Resolution()
// //let someResolution = Resolution(width: 0, height: 0)
// print(someResolution)

let hd = Resolution(width: 1920, height: 1080)
print("HD: \(hd)")

var cinema = hd
cinema.width  = 800
cinema.height = 600

print("HD: \(hd)")
print("Cinema: \(cinema)")

//ReFerence Type Explaination
//_________________________________________________________________
let tenEigthy = VideoMode()
print("\(tenEigthy.resolution), \(tenEigthy.interlaced), \(tenEigthy.frameRate)")

tenEigthy.resolution = hd
tenEigthy.interlaced = true
tenEigthy.name = "1080 High Density"
tenEigthy.frameRate = 60
print("\(tenEigthy.resolution), \(tenEigthy.interlaced), \(tenEigthy.frameRate)")

let tenEigthyOnceMore = tenEigthy
print("\(tenEigthyOnceMore.resolution), \(tenEigthyOnceMore.interlaced), \(tenEigthyOnceMore.frameRate)")

tenEigthy.frameRate = 90
print("\(tenEigthy.resolution), \(tenEigthy.interlaced), \(tenEigthy.frameRate)")
print("\(tenEigthyOnceMore.resolution), \(tenEigthyOnceMore.interlaced), \(tenEigthyOnceMore.frameRate)")


//Mutability and Immutability In Structure Memebers
//	 Parent Immutability Also Applicable To Every Child Members 
//		Irrespective of It Being Mutable or Immutable
//	 Parent Mutability NOT Applicable To Every Child Members
//		Child Preserves It's Mutable or Immutable Charater
//_________________________________________________________________

struct FixedLengthRange {
    var firstValue: Int
    let length: Int
}

let rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
print(rangeOfThreeItems)
rangeOfThreeItems.firstValue = 6
//rangeOfThreeItems.length = 10
print(rangeOfThreeItems)




