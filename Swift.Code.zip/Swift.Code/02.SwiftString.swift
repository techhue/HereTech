
let someValue = "Some String Value!"
print(someValue)

var emptyString = ""
print(emptyString)

var anotherEmtpyString = String()
print(anotherEmtpyString)

if emptyString.isEmpty {
	print("Empty String...")
} else {
	print("Value is: \(emptyString)")
}

if anotherEmtpyString.isEmpty {
	print("Empty String...")
} else {
	print("Value is: \(emptyString)")
}

var someString = "Hello"
someString = someString + " World!"
someString += " Chak De India!!!!"
print(someString)

var someNumber = 100
someNumber = someNumber + 1000
print(someNumber)

someString = someString + String(someNumber)
print(someString)


// a...b Range Operator: a ... b It's Close Interval [a, b]
for index in 1 ... 5 {
	print( "\(index) times 5 is \(index * 5)" )
}

let names = ["Anna", "Dyna", "Ashwarya", "Katrina", "Sonali Kulkarni", "Mukta Barve"]

// a ..< b Range Operator: It's Semi-Closed Interval [a, b)
for i in 0 ..< names.count {
	print(names[i])
}

print(names[-1])


