enum CompassPoint {
	case North
	case South
	case East
	case West
}

var direction = CompassPoint.North
//In Swift Switch Expression is Type Safe
switch direction {
	case .North:
		print("Heading North..")
	case .South:
		print("Heading South..")
	case .East:
		print("Heading East..")
	case .West:
		print("Heading West..")
	// default:
	// 	print("Heading To Unknown...")
}

enum Planet: Int {
    case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

let somePlanet: Planet = .Earth
switch somePlanet {
case .Earth:
    print("Livable... Awesome Earth...")
default:
    print("Not a safe place for humans")
}

print(somePlanet)
print(Planet.Earth.rawValue)

let somePoint = (1,1)
switch somePoint {
	case (0, 0):
	    print("(0,0) is at the origin")
	case (_, 0):
	    print("\(somePoint.0),0) is on the x-axis")
	case (0, _):
	    print("(0, \(somePoint.1)) is on the y-axis")
	case (-2...2, -2...2):
	    print("(\(somePoint)) is inside the box")
	// default:
	//     print("(\(somePoint)) is outside of the box")
	case (_, _):
		print("(\(somePoint)) is inside the box")
}




