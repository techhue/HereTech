
func helloWorld() {
	print("Hello World!")
}

helloWorld()

func sayHello(personName: String) -> String {
	let greeting = "Hello " + personName + "!"
	return greeting
}
print(sayHello(personName: "Ashywarya Rai"))

//In JAVA 
// String sayHello(String personName, String message) {   }
// sayHello("Ashywarya Rai", "I Love You!")

func sayHelloAgain(personName: String, message: String) -> String {
	let greeting = "Hello " + personName + "!" + "\n" + message
	return greeting
}
print(sayHelloAgain(personName: "Ashywarya Rai", message: "I Love You!"))

func sum1(value1: Int, value2: Int) -> Int {
	return value1 + value2
}
print(sum1(value1: 100, value2: 90))

func printAndCount(someString: String) -> Int {
	print(someString)
	return someString.count 
}
print(printAndCount(someString: "Ding Dong"))

func minMax(numbers: [Int]) -> (Int, Int) {
	var minValue = numbers[0]
	var maxValue = numbers[0]

	//Iterator: Iterate On Sequence
	for number in numbers {
		if number < minValue {
			minValue = number
		}

		if number > maxValue {
			maxValue = number
		}
	}

	return (minValue, maxValue) //You Can Return More Than One Value
}

let values = minMax(numbers: [10, 20, 90, -10, -100, 788, 899, 60, 70])
print(values)

//Calculates Total Marks of One Student
func calculateTotal(student: String, mathMarks: Float, scienceMarks: Float) -> (String, Float) {
	let totalMarks = mathMarks + scienceMarks
	return (student, totalMarks)
}
print(calculateTotal(student: "Ram", mathMarks: 100, scienceMarks: 90))

// CODING ASSIGNMENT
//___________________________________________________________________________
	// Write A Function To Calculate Total Marks of All Students
	// Return Students with It's Total Marks
func calculateTotal1(students: [ (name: String, mathMarks: Int, scMarks: Int) ] ) 
-> [ (name: String, totalMarks: Int) ] {

	var totalMarks : [ (String, Int) ] = []
	for student in students { 
		totalMarks.append( (student.name, student.mathMarks + student.scMarks ) )
	} 
	return totalMarks
}
var studentsArray = [("Ram", 30, 40), ("Shyam", 100, 90), ("Sachin", 80, 80)]
print(studentsArray)
let studentsTotal = calculateTotal1(students: studentsArray)
print(studentsTotal)

for student in studentsTotal {
	print("\(student.name) Total Marks: \(student.totalMarks)")
}

func calculateTotal2(students: [ String : (Int, Int) ] ) -> [ (String, Int) ] {
	var totalMarks : [ (String, Int) ] = []
	for (student, marks) in students { 
	 	totalMarks.append( (student, marks.0 + marks.1 ) )
	}
	return totalMarks	
}
var studentsDictonary = ["Ram": (30, 40), "Shyam":(100, 90), "Sachin": (80, 80)] 
print(studentsDictonary)
let studentsTotal1 = calculateTotal2(students: studentsDictonary)
print(studentsTotal1)

func calculateTotal3(students: [ String : (Int, Int) ]) -> [ String : Int ] {
	var totalMarks : [ String : Int ] = [:]
	for (student, marks) in students { 
	 	totalMarks[student] = marks.0 + marks.1
	}
	return totalMarks
}
print(studentsDictonary)
let studentsTotal2 = calculateTotal3(students: studentsDictonary)
print(studentsTotal2)


func minMax1(numbers: [Int]) -> (min: Int, max: Int) {
	var minValue = numbers[0]
	var maxValue = numbers[0]

	//Iterator: Iterate On Sequence
	for number in numbers {
		if number < minValue {
			minValue = number
		}

		if number > maxValue {
			maxValue = number
		}
	}

	return (minValue, maxValue) //You Can Return More Than One Value
}

let values1 = minMax1(numbers: [10, 20, 90, -10, -100, 788, 899, 60, 70])
print(values1)
print(values1.min, values1.max)


//BAD API DESIGN: BECAUSE THEY DOESN'T NAMES MEANINGFULLY...
func join(s1: String, s2: String, joiner: String) -> String {
	return s1 + joiner + s2
}
print(join(s1: "Ashywarya", s2: "Rai", joiner: " "))


//GOOD API DESIGN: HUMARE NAAM KE MEANING HOTE HAIN...
//External and Internal Parameter Names
//Hathi Ke Danth: Dikhane Ke Aur... Khane Ke Aur
func join(string s1: String, toString s2: String, withJoiner joiner: String = " ") -> String {
	return join(s1: s1, s2: s2, joiner: joiner)
}
print(join(string: "Ashywarya", toString: "Rai", withJoiner: " "))
print(join(string: "Ashywarya", toString: "Rai"))
print(join(string: "Ashywarya", toString: "Rai", withJoiner: "___"))
print(join(string: "Ashywarya", toString: "Rai", withJoiner: "Chummi"))

func contains(string: String, character: Character) -> Bool {
	for c in string {
		if c == character {
			return true
		}
	}
	return false
}

if contains(string: "Ding Dong", character: " ") {
	print("Contains Space...")
}

func TruthValue(value: Int) -> Bool {
	return ( value == 0 ) ? false : true
}

if TruthValue(value: 10) {
	print("Truth...")
} else {
	print("False...")
}

func constructName(firstName: String, lastName: String = "", title: String = "") -> String {
	return title + "  " + firstName + " " + lastName
}

print(constructName(firstName: "Ram"))
print(constructName(firstName: "Ramu", lastName: "Singh"))
print(constructName(firstName: "Ramu", lastName: "Singh", title: "Mr."))

//Variable Number of Arguments.
//Varidiac Arguments...
func arithmaticMean(numbers: Double...) -> Double {
	var total: Double = 0
	for number in numbers {
		total = total + number
	}
	return total / Double(numbers.count)
}

print(arithmaticMean(numbers: 1, 2, 3, 4, 5))
print(arithmaticMean(numbers: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10))

//Pass By Reference
func swap(a: inout Int, b: inout Int) {
	let tempValue = a
	a = b
	b = tempValue
}

var a = 10
var b = 20
swap(&a, &b)
print(a, b)

var numbers = [10, 20, 30, 40]
print(numbers)

//Pass By Reference
func multiply(numbers: inout [Int], multiplier: Int) {
	// var numbers = numbers
	var index = 0
	for _ in numbers {
		numbers[index] = numbers[index] * multiplier
		index = index + 1
	}
	print("Inside: \(numbers)")
}

multiply(numbers: &numbers, multiplier: 2)
print(numbers)

//_________________________________________________________________


func sum(a: Int, b: Int) -> Int { return a + b }
func sub(a: Int, b: Int) -> Int { return a - b }
func mul(a: Int, b: Int) -> Int { return a * b }

//Polymorphic Function: Passing A Function To A Function
func calculator(a: Int, b: Int, operation: (Int, Int) -> Int ) -> Int { 
	return operation(a, b) 
}

let aa = 10
let bb = 20
var result = 0

result = calculator(a: aa, b: bb, operation: sum)
print("Result Is: \(result)")

result = calculator(a: aa, b: bb, operation: sub)
print("Result Is: \(result)")

result = calculator(a: aa, b: bb, operation: mul)
print("Result Is: \(result)")

func sum3(a: Int, b: Int, c: Int) -> Int { return a + b + c  }

let mathFunction = sum
//let mathFunction: (Int, Int) -> Int = sum3
print(mathFunction(11, 22))


//_________________________________________________________________

func stepForward(input: Int) -> Int {
	return input + 1
}

func stepBackward(input: Int) -> Int {
	return input - 1
}

//Can Return Function From Function
func chooseFunction( backwards: Bool = false ) -> (Int) -> Int {
	return backwards ? stepBackward : stepForward
}

var currentValue = 3

var operation: (Int) -> Int = chooseFunction()
result = operation(currentValue)
print(result)

operation = chooseFunction(backwards: true)
result = operation(currentValue)
print(result)


//NESTED FUNCTION: Function Inside Function
func orderingWife( goodMood: Bool = false ) -> (Int) -> Int {
	func stepForward(input: Int) -> Int { return input + 10 }
	func stepBackward(input: Int) -> Int { return input - 10 }	
	return goodMood ? stepBackward : stepForward
}

operation = orderingWife( goodMood: true)
result = operation(currentValue)
print(result)

operation = orderingWife( goodMood: false)
result = operation(currentValue)
print(result)

//_________________________________________________________________________

func moveTowardsZero(currentValue: Int) {
	var currentValue = currentValue
	while currentValue != 0 {
		print(currentValue)
		if currentValue > 0 {
			currentValue = currentValue - 1
		} else if currentValue < 0  {
			currentValue = currentValue + 1
		}
	}
	print("Reached Zero...")
}

print("moveTowardsZero Function...")
moveTowardsZero(currentValue: -4)
moveTowardsZero(currentValue: 4)


//_________________________________________________________________________


//NESTED FUNCTION: Function Inside Function
func choose( choice: Bool = false ) -> (Int) -> Int {
	func stepForward(input: Int) -> Int { return input + 1 }
	func stepBackward(input: Int) -> Int { return input - 1 }	
	return choice ? stepBackward : stepForward
}


//Alogrithm Invariant : Doesn't Change With Time...
func playChessMove(currentValue: Int) {
	var currentValue = currentValue
	let moveNearerToZero: (Int) -> Int = choose( choice: currentValue > 0)

	while currentValue != 0 {
		print("\(currentValue)")
		currentValue = moveNearerToZero(currentValue)
	}
	print("Zero!")
}

print("play Move....")
playChessMove(currentValue: -4)
playChessMove(currentValue: 4)

func playSnakeAndLadderMove(currentValue: Int) {
	var currentValue = currentValue
	let moveNearerToZero: (Int) -> Int = choose( choice: currentValue > 0)

	while currentValue != 0 {
		print("\(currentValue)")
		currentValue = moveNearerToZero(currentValue)
	}
	print("Zero!")
}








