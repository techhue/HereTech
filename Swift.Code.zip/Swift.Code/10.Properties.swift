//Mutability and Immutability In Structure Memebers
//	 Parent Immutability Also Applicable To Every Child Members 
//		Irrespective of It Being Mutable or Immutable
//	 Parent Mutability NOT Applicable To Every Child Members
//		Child Preserves It's Mutable or Immutable Charater
//_________________________________________________________________

struct FixedLengthRange {
    var firstValue: Int
    let length: Int
}

//let rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
var rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
print(rangeOfThreeItems)
rangeOfThreeItems.firstValue = 6
//rangeOfThreeItems.length = 10
print(rangeOfThreeItems)

class DataImporter {
    var fileName = "dataFile.txt"

    init() {
    	//self.fileName = fileName
    	print("DataImporter Object Getting Created")
    }
}

class DataManager {
    // lazy var importer = DataImporter()
    var importer = DataImporter()
    var data = [String]()

    init() {
    	print("DataManager Object Getting Created")
    	self.data = ["Ding", "Dong"]
    }
}

let manager = DataManager()
print(manager.data)
print(manager.importer.fileName)

struct Point {
    var x = 0.0, y = 0.0
}
struct Size {
    var width = 0.0, height = 0.0
}
struct Rect {
	//Stored Property
    var origin = Point()
    var size = Size()
    //Commputed Property
    var center: Point {
	    get {
	        let centerX = origin.x + (size.width / 2)
	        let centerY = origin.y + (size.height / 2)
	        return Point(x: centerX, y: centerY)
	    }
	    set(newCenter) {
	        origin.x = newCenter.x - (size.width / 2)
	        origin.y = newCenter.y - (size.height / 2)
	    }
    }
}
var square = Rect(origin: Point(x: 0.0, y: 0.0), size: Size(width: 10.0, height: 10.0))
let initialSquareCenter = square.center
print("square.origin is now at (\(square.origin.x), \(square.origin.y))")
print("square.center is now at (\(square.center.x), \(square.center.y))")
square.center = Point(x: 15.0, y: 15.0)
print("square.origin is now at (\(square.origin.x), \(square.origin.y))")
print("square.center is now at (\(square.center.x), \(square.center.y))")

// struct Rect1 {
// 	//Stored Property
//     var origin = Point()
//     var size = Size()
//     //Commputed Property
//     var center: Point {
// 	        let centerX = origin.x + (size.width / 2)
// 	        let centerY = origin.y + (size.height / 2)
// 	        return Point(x: centerX, y: centerY)
//     }
// }
// var square1 = Rect1(origin: Point(x: 0.0, y: 0.0), size: Size(width: 10.0, height: 10.0))
// let initialSquareCenter1 = square.center
// // print("square1.origin is now at (\(square1.origin.x), \(square1.origin.y))")
// // print("square.center is now at (\(square.center.x), \(square1.center.y))")
// square1.center = Point(x: 15.0, y: 15.0)
// // print("square.origin is now at (\(square.origin.x), \(square.origin.y))")
// // print("square.center is now at (\(square.center.x), \(square.center.y))")


class StepCounter {
    var totalSteps: Int = 0 {
	    willSet(newTotalSteps) {
	        print("About to set totalSteps to \(newTotalSteps)")
	    }

	    didSet {
	        if totalSteps > oldValue {
	            print("Added \(totalSteps - oldValue) steps")
	        }
	    }
    }
}

let stepCounter = StepCounter()
stepCounter.totalSteps = 200
stepCounter.totalSteps = 360
stepCounter.totalSteps = 896








struct SomeStructure {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 1
    }
}

enum SomeEnumeration {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 6
    }
}

class SomeClass {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 27
    }
}

print(SomeStructure.storedTypeProperty)             // prints "Some value."
SomeStructure.storedTypeProperty = "Another value."
print(SomeStructure.storedTypeProperty)             // prints "Another value."
print(SomeEnumeration.computedTypeProperty)         // prints "6"
print(SomeClass.computedTypeProperty)               // prints "27"


