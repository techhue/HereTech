#include <stdio.h>
#include <limits.h>

//Assume Machine Achitecture is 16 Bit
//Range of C int is [-32768, 32767]

//Either Return Valid Sum
//Or Print Not Able To Calculate Sum for Given a, b

/*
int sumBad1(int a, int b) {
 	return a + b;
}

int sumBad2(int a, int b) {
	int result = 0;
	if (a >= INT_MIN && a <= INT_MAX) && (b >= INT_MIN && b <= INT_MAX) {
		result = sum(a, b);
	}

	if (result >= INT_MIN && result <= INT_MAX) {
		printf("\nResult Is: %d\n", result);	
	} else {
		printf("\nNot Able To Calculate Sum for Given a, b");	
	}
}

long sumBad2(int a, int b) {
	long result = 0;
	if (a >= INT_MIN && a <= INT_MAX) && (b >= INT_MIN && b <= INT_MAX) {
		result = sum(a, b);
	}

	if (result >= INT_MIN && result <= INT_MAX) {
		printf("\nResult Is: %d\n", result);	
	} else {
		printf("\nNot Able To Calculate Sum for Given a, b");	
	}
}

int sumGood(signed int x, signed int y) {
	signed int result = 0;

	if ( (x > 0 && y < (INT_MAX - x)) { 
		|| (x < 0 && y > (INT_MIN - x)) ) {
		result = x + y;
		
	} else {
		printf("\n Unable to calculate sum... Invalid");
	}
}	
*/

int sumGood(signed int x, signed int y) {
	signed int result = 0;
	//OverFlow/UnderFlow Detection
	if ( (x > 0 && y > (INT_MAX - x)) ||
	     (x < 0 && y < (INT_MIN - x)) ) {
		printf("\n Unable to calculate sum... Invalid");
	} else {
	//Valid Result
		result = x + y;
	}
	
	return result;
}

int sum3(int a, int b, int c) {
	return a + b + c;
}

int main() {
	int a = 32000;
	int b = 32000;
	int result = 0;

	//int (*fptr)(int, int) = sumGood;
	int (*fptr)(int, int) = sum3;
	// result = sumGood(a, b);
	// printf("\nResult : %d", result);
	result = fptr(a, b);
	printf("\nResult : %d", result);
}

//Exptected Result: 38394398493850
//Actual Result: 1685834906