
func canThrowError() throws {
    // This function may or may not throw an error.
}

do {
	try canThrowError()
	//No Error - This Part of Code Will Runs...
	//
} catch { //Error - catch Block Code Will Runs...

}